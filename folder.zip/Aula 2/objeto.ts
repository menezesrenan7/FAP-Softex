// 1. Crie um objeto chamado "pessoa" com as propriedades "nome", "idade" e "endereço" e atribua valores a elas.
    let pessoa = {
        nome: "Renan",
        idade: 33,
        endereco: "Rua Sa e Souza",
    } as any; 

// 2. Acesse o valor da propriedade "nome" do objeto "pessoa".
    pessoa.nome;

// 3. Adicione uma nova propriedade chamada "profissao" ao objeto pessoa e atribua um valor a ela.
    pessoa.profissao = "Administrador";

// 4. Atualize o valor da propriedade "idade" do objeto pessoa para um novo valor.
    pessoa.idade = 34;

// 5. Crie outro objeto chamado "animal" com as propriedades "nome", "especie" e "cor" e atribua valores a elas.
    let animal = {
        nome: "Raul",
        especie1: "Tigre",
        cor1: "amarelo",
    }

// 6. Crie um objeto chamado "livro" com as propriedades "titulo", "autor" e "ano" e atribua valores a elas.
    type Livro = {titulo: string; autor: string; ano: number};

    let livro: Livro = {
        titulo: "Os miseraveis",
        autor: "Victor Hugo",
        ano: 1964
    };

// 7. Acesse o valor da propriedade "autor" do objeto livro.
    livro.autor;

// 8. Atualize o valor da propriedade "ano" do objeto livro para um novo valor.
    livro.ano = 2000;

// 9. Exclua a propriedade "titulo" do objeto utilizando o operador "delete".
    delete (livro as {titulo?: string}).titulo;