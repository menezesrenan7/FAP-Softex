let x = 2;
// 1.Utilizando a função "console.log", verifique se dois números são iguais utilizando o operador de igualdade ("==").
    console.log(2 == 2);
// 2. Utilizando a função "console.log", verifique se dois números são diferentes utilizando o operador de diferença ("!=").
    console.log(2 != 2);
// 3. Utilizando a função "console.log", verifique se um  número é maior que outro utilizando o operador de maior que (">").
    console.log( 2 > 3);
// 4. Utilizando a função "console.log", verifique se um número é menor que outro utilizando o operador de menor que ("<").
    console.log(2 < 3);
// 5. Utilizando a função "console.log", verifique se um número é maior ou igual a outro utilizando o operador de maior ou igual a (">=").
    console.log( 2 >= 2);
// 6. Utilizando a função "console.log", verifique se um número é menor ou igual a outro utilizando o operador de menor ou igual a ("<=").
    console.log(2 <= 2);
// 7. Utilizando a função "console.log", verifique se duas condições são verdadeiras utilizando o operador lógico AND ("&&").
    console.log(2 == 2 && typeof(9) === typeof(4));
// 8. Utilizando a função "console.log", verifique se pelo menos uma das condições é verdadeira utilizando o operador lógico OR ("||").
    console.log(2 == 2 || typeof(9) === typeof(4));
// 9. Utilizando a função "console.log", negue uma condição utilizando o operador lógico NOT ("!").
    console.log(2 != 2);
// 10. Utilizando a função "console.log", verifique se um número está dentro de um determinado intervalo, utilizando os operadores lógicos AND e os operadores de comparação (">=" e "<=").
    console.log( x > 0 && x < 5);
// 11. Utilizando a função "console.log", verifique se um número está fora de um determinado intervalo, utilizando os operadores lógicos OR e os operadores de comparação ("<" e ">").
    console.log(5 > 4 || 5 < 6)
// 12. Utilizando a função "console.log", verifique se um número é positivo, utilizando o operador de maior que (">") e o operador de igualdade ("==") para verificar se o número é maior que zero.
    console.log(x >= 0);
// 13. Utilizando a função "console.log", verifique se uma string é vazia, utilizando o operador de igualdade ("==") e o operador de tamanho ("length") para verificar se o tamanho da string é igual a zero.
    let array2 = [];
    console.log(array2.length == 0)
// 14. Utilizando a função "console.log", verifique se uma variável é do tipo booleano, utilizando o operador "typeof" e o operador de igualdade ("==") para verificar se o tipo de dado é igual a "boolean".
    console.log(typeof x == "boolean");