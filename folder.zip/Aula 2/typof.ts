// 1. Crie uma variável chamada "numero" e atribua a ela um número qualquer. Verifique o tipo de dado dessa variável usando "typeof".
    let numero = 2;
    typeof(numero);

// 2. Crie uma variável chamada "texto" e atribua a ela uma string qualquer. Verifique o tipo de dado dessa variável usando "typeof".
    let texto = "Renan";
    typeof(texto);

// 3. Crie uma variável chamada "booleano" e atribua a ela um valor booleano ("true" ou "false"). Verifique o tipo de dado dessa variável usando "typeof".
    let booleano = true;
    typeof(booleano);

// 4. Crie uma variável chamada "array" e atribua a ela um array vazio. Verifique o tipo de dado dessa variável usando "typeof".
    let array = [];
    typeof(array);

// 5. Crie uma variável chamada "objeto" e atribua a ela um objeto vazio. Verifique o tipo de dado dessa variável usando "typeof".
    let objeto1 = {};
    typeof(objeto1);

// 6. Crie uma variável chamada "nulo" e atribua a ela o valor nulo ("null"). Verifique o tipo de dado dessa variável usando typeof.
    let nulo = null;
    typeof(nulo);

// 7. Crie uma variável chamada "indefinido" sem atribuir nenhum valor. Verifique o tipo de dado dessa variável usando "typeof".
    let indefinido;
    typeof(indefinido);