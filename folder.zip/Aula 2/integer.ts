// 1. Declare uma constante chamada" PI" e atribua a ela o valor de 3.14159.
    const PI: number = 3.14159;

// 2. Declare uma nova variável chamada "y" e atribua a ela o valor da constante "PI".
const y: number = PI;

// 3. Declare uma constante chamada "taxaJuros" e atribua a ela o valor de 0.05, representando uma taxa de juros de 5%.
    const taxaJuros: number = 0.05;

// 4. Declare duas variáveis "x" e "y" e atribua para elas valores inteiros;
    let x: number = 10;
    let yy: number = 20;

// 5. Exiba no terminal a "soma" dessas duas variáveis.
    console.log(x + yy);

// 6. Exiba no terminal a "subtração" dessas duas variáveis.
    console.log(x - yy);

// 7. Exiba no terminal a "multiplicação" dessas duas variáveis.
    console.log(x * yy);

// 8. Exiba no terminal a "divisão" dessas duas variáveis.
    console.log(x / yy);
