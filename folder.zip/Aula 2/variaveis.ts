// 1. Declare uma variável chamada "variavelNull" e atribua a ela o valor nulo ("null").
    let variavelNull = null;

// 2. Declare uma variável chamada "variavelUndefined" e não atribua nenhum valor a ela.
    let variavelUndefined;

// 3. Verifique se a variável "variavelNull" é igual a "null".
    variavelNull == null;

// 4. Verifique se a variável "variavelUndefined" é igual a "undefined".
    variavelUndefined == undefined;

// 5. Atribua o valor "undefined" a uma propriedade chamada "nome" de um objeto vazio.
    let objeto = {nome: undefined};