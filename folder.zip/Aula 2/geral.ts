// GERAL

// 1. Defina o que é um variável na programação.
    "Variável é um espaço criado na memória do programa para receber um ou mais valores";
    
// 2. Escreva com as suas palavras a diferença entre as declarações const, let e var e como elas podem ser aplicadas na prática.
    "const é utilizado para reservar um valor fixo, que não pode ser alterado durante a execução do problema"
    
    "let é atualmente o comando utilizado para receber variáves, ou seja, dados que podem ter seu valor alterado durante a execução do programa."
    
    "var é um comando depreciado (não mais utilizado) para criar uma variável."

// 3. Explique a diferença entre as variáveis do tipo objeto e lista.
    "Listas são uma coleção de informações organizadas de forma ordenada, através de índices numéricos."
    
    "Objetos, por outro lado, são utilizados para representar conceitos ou entidades do mundo real, sendo formados por propriedades que representam características ou comportamentos do objeto em questção. Os objetos não possuem uma ordem específica com encontrada nas listas."
     