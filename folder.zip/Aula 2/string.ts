// 1. Crie uma variável chamada "nome" e atribua a ela uma string com seu nome. Em seguida, exiba oconteúdo da variável "nome" no terminal.
    let nome: string = "Renan";
    console.log(nome)

// 2. Crie uma variável chamada "frase" e atribua a ela uma frase de sua escolha. Em seguida, exiba o comprimento da string armazenada na variável "frase".
    let frase: string = "O dia só termina quando acaba";
    console.log(frase.length);

// 3. Crie uma variável chamada "palavra" e atribua a ela uma palavra qualquer. Em seguida, exiba a primeira letra da palavra armazenada na variável "palavra".
    let palavra: string = "Hoje";
    console.log(palavra.charAt(0));

// 4. Crie uma variável chamada "frase" e atribua a ela uma frase de sua escolha. Em seguida, exiba a frase em letras maiusculas.
    let frase1: string = "A bicicleta anda";
    console.log(frase1.toUpperCase);

// 5. Crie uma variável chamada "endereço" e atribua a ela um valor de sua escolha. Em seguida, sobrescreva o valor da variável para um outro endereço e verifique no terminal o valor atual da variável.
    let endereco: string = "Av. Engenheiro Domingos Ferreira";
    endereco = "Rua Sá e Souza";
    console.log(endereco);