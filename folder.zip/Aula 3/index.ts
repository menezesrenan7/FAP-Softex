// Implemente o código do slide de número 5.
let frase = prompt("Entre a primeira frase");
console.log(frase);

// 2. Implemente o código do slide de número 13.
let string = "123";
console.log(typeof Number(string));

let number = "321";
console.log(typeof String(number));

// 3. Implemente o código do slide de número 16.

let numero1 = prompt("Digite o primeiro número");
let numero2 = prompt("Digite o segundo número");

let resultado = Number(numero1) + Number(numero2);
console.log(resultado);

// 4. Implemente o código do slide de número 23.

let string1 = "Estudar ";
let string2 = "é bom";
console.log(string1 + string2);

let numero3 = 48;
console.log(string1 + string2 + " " + numero3);

// 5. Solicite ao usuário seu nome e imprima uma mensagem de boas-vindas na tela.

let nome = prompt("Digite seu nome");
alert("Bem-vindo" + " " + nome);

// 6. Peça ao usuário que digite sua idade em texto (por exemplo, "18") e converta-a em um número inteiro.

let idade = Number(prompt("Digite sua idade em texto:"));

// 7. Receba um número inteiro do usuário e converta-o em um número decimal (float).

let numero = Number(prompt("Digite um número inteiro do usuário:"));
console.log(numero.toFixed());

// 8. Peça ao usuário para digitar dois números inteiros e exiba a soma deles.

let numero01 = Number(prompt("Digite o primeiro número:"));
let numero02 = Number(prompt("Digite o segundo número:"));

alert(numero01 + numero02);

// 9. Receba um número decimal do usuário e calcule o seu quadrado.

let decimal = Number(prompt("Digite um número decimal:"));

alert(decimal ** 2);

// 10. Peça ao usuário que insira o seu ano de nascimento e, em seguida, exiba a sua idade.

let anoNascimento = Number(prompt("Insira o ano de seu nascimento:"));
const anoHoje = new Date().getFullYear();
alert(anoHoje - anoNascimento);

// 11. Peça ao usuário que digite seu primeiro nome e seu sobrenome separadamente. Em seguida, concatene-os em uma única string e exiba o nome completo.

let primeiroNome = String(prompt("Digite seu primeiro nome:"));
let sobrenome = String(prompt("Digite seu sobrenome:"));

let nomeCompleto = primeiroNome + sobrenome;

alert(nomeCompleto);

// 12. Solicite ao usuário uma sequência de números separados por espaço e exiba quantos números foram digitados.

let sequenciaNumeros = String(prompt("Digite uma sequência de números separados por espaço:"));
let quantidadeSequencia = sequenciaNumeros.replace(/\s+/g, "");
alert(quantidadeSequencia.length);


// 13. Receba o nome de um animal digitado pelo usuário e exiba uma mensagem informando qual animal foi digitado.

let animal = prompt("Digite o nome de um animal");
alert(animal);

// 14. Peça ao usuário que digite o seu nome e o seu sobrenome. Em seguida, exiba o nome completo invertido (sobrenome, nome).

let nomeCompleto1 = String(prompt("Digite seu nome completo:"));
let nomeInvertido = nomeCompleto1.split(" ").reverse();

// 15. Receba uma string digitada pelo usuário e imprima o seu tamanho (número de caracteres).

let str = prompt("Digite uma string:");
alert(str?.length);

// 16. Solicite ao usuário um número inteiro e exiba se ele é par ou ímpar.

let numero4 = Number(prompt("Digite um número:"));

if (numero4 % 2 == 0) {
    alert("Par");
} else {
    alert("ímpar");
}

// 17. Receba um número inteiro digitado pelo usuário e verifique se ele é positivo ou negativo.

let numero5 = Number(prompt("Digite um número inteiro:"));

if (numero5 < 0) {
    alert("Número negativo");
} else {
    alert("Número positivo");
}

// 18. Peça ao usuário que insira dois números e exiba o maior deles.

let numero6 = Number(prompt("Digite um número"));
let numero7 = Number(prompt("Digite novamente um número"));

if (numero6 > numero7) {
    alert(numero6);
} else {
    alert(numero7);
}


// 19. Receba a altura e o peso de uma pessoa digitados pelo usuário. Em seguida, calcule o seu índice de
// massa corporal (IMC) utilizando a fórmula: IMC = peso / (altura * altura) e exiba o resultado.

let altura = Number(prompt("Digite a altura:"));
let peso = Number(prompt("Digite o peso:"));
let imc = peso / (altura^2);
alert(imc);

// 20. Peça ao usuário que digite o seu nome e verifique se ele contém mais de 5 caracteres.

let nome1 = String(prompt("Digite seu nome:"));

if (nome1?.length > 5) {
    alert("Seu nome possui mais de 5 caracteres.");
} else{
    alert("Seu nome possui igual ou menos de 5 caracteres.");
};

// 21. Solicite ao usuário que insira o seu estado civil e exiba uma mensagem apropriada (por exemplo:
// "Você é casado(a)", "Você é solteiro(a)", etc.).

let estadoCivil = prompt("Insira seu estado civil:");
alert("Você é " + estadoCivil + "(a)");

// 22. Receba a base e a altura de um retângulo digitados pelo usuário. Em seguida, calcule a sua área e
// exiba o resultado.

let base = Number(prompt("Digite o valor da base: "));
let altura1 = Number(prompt("Digite o valor da altura: "));
let areaRetangulo = base * altura1;

alert("O valor da área do retângulo é: " + areaRetangulo);

// 23. Peça ao usuário que digite a sua cidade e verifique se ela começa com a letra "S" (ou outra letra de
// sua escolha).

let cidade = String(prompt("Digite o nome da sua cidade: "));

if (cidade.charAt(1) !== "S") {
    alert("A cidade não começa com a letra 'S'.");
}

// 24. Solicite ao usuário que insira dois números decimais e calcule o resto da divisão entre eles.

let numero8 = Number(prompt("Digite o primeiro valor decimal: "));
let numero9 = Number(prompt("Digite o segundo valor decilmal: "));
let resto = Number(numero8.toFixed(2)) % Number(numero9.toFixed(2));

alert(resto);

// 25. Solicite ao usuário um número decimal e converta-o em um número inteiro.
let decimal1 = Number(prompt("Digite um número decimal:"));
let decimal2 = decimal.toFixed(0);

// 26. Receba uma string contendo um número inteiro e some 10 a esse número, convertendo-o
// novamente para uma string antes de exibi-lo.

let string3 = Number(prompt("Digite um número inteiro:"));

alert(String(string3));

// **** 27. Solicite ao usuário que digite uma data no formato "dd/mm/aaaa" e extraia o dia, o mês e o ano
// separadamente, convertendo-os em números inteiros.

let date = prompt("Digite uma data no formato 'dd/mm/aaaa':");

let regexp = new RegExp(/[0-31]{2}?=//);
let teste = RegExp.test(date);
let dividedDate = date?.split("/");
if (typeof dividedDate !== undefined) {
    let day = dividedDate;
}


// 28. Receba o nome de uma cidade do usuário e concatene-o com o nome do estado para formar uma
// mensagem completa, como "Você mora em [cidade], [estado].".

let cidade1 = prompt("Digite sua cidade:");
let estado = prompt("Digite seu Estado:");
alert("Voce mora em " + cidade1 + estado);

// 29. Solicite ao usuário que insira seu ano de nascimento e concatene-o com uma mensagem de
// boas-vindas, como "Bem-vindo ao nosso programa, nascido em [ano de nascimento]!".

let anoNascimento1 = prompt("Digite o ano do seu nascimento:");
alert("Bem-vindo ao nosso programa, nascido em " + anoNascimento1);

// 30. Receba um número inteiro e uma string do usuário. Em seguida, concatene-os em uma única
// string, separando-os com um espaço.

let inteiro = prompt("Digite um número inteiro:");
let string4 = prompt("Digite uma string:");
alert(`${inteiro} + " " + ${string4}`);

// 31. Receba o nome de um produto digitado pelo usuário e concatene-o com o preço do produto,
// adicionando o símbolo de moeda da sua escolha.

let produto = prompt("Digite o nome do produto:");
let preco = prompt("Digite o preço do produto:");

alert(`${produto} + " " + "R$" + " " + ${preco}`);

// 32. Receba um número inteiro do usuário e concatene-o com uma mensagem, informando o dobro
// desse número.

let numero10 = Number(prompt("Digite um número:"));
alert(`O dobro do seu número é ${numero10 * 2}`);

// 33. Receba uma string contendo um endereço de e-mail e concatene-a com uma mensagem de
// agradecimento personalizada.

let email = String(prompt("Digite seu endereço de e-mail:"));
alert("Obrigado pelo seu e-mail: " + email);

// 34. Receba dois números inteiros do usuário e exiba a soma, a diferença, o produto e o quociente
// (divisão inteira) entre eles.

let primeiroNumero = Number(prompt("Digite o primeiro número: "));
let segundoNumero = Number(prompt("Digite o segundo número: "));

alert(primeiroNumero + segundoNumero);
alert(primeiroNumero - segundoNumero);
alert(primeiroNumero * segundoNumero);
alert(primeiroNumero / segundoNumero);

// 35. Peça ao usuário para digitar a base e a altura de um triângulo. Em seguida, calcule e exiba a área do
// triângulo.

let base1 = Number(prompt("Digite a base:"));
let altura2 = Number(prompt("Digite a altura:"));
let areaTriangulo = base & altura2 / 2;

alert(areaTriangulo);

// 36. Receba o raio de uma circunferência digitado pelo usuário e calcule o seu perímetro (2 * π * raio).

let raioCircunferencia = Number(prompt("Digite/ o raio da circunferencia:"));
let perimetro = 2 * 3.14 * raioCircunferencia;

// 37. Receba a base e a altura de um retângulo digitados pelo usuário. Em seguida, calcule e exiba o
// perímetro do retângulo.

let baseRetangulo = Number(prompt("Digite a base do retângulo:"));
let alturaRetangulo = Number(prompt("Digite a altura do retângulo:"));

alert(baseRetangulo * alturaRetangulo);

// 38. Solicite ao usuário que insira três números decimais. Em seguida, calcule e exiba a média
// aritmética desses números.

let decimal3 = Number(prompt("Digite três números decimais:"));
let decimal4 = Number(prompt());
let decimal5 = Number(prompt());

alert(`A média é: ${(decimal3 + decimal4 + decimal5) / 3}`);

// 39. Peça ao usuário para digitar a sua idade e, em seguida, informe quantos meses e quantos dias ele já
// viveu (considerando um ano com 365 dias).

let idade1 =  Number("Digite sua idade:");

let meses = idade1 * 12;
let dias = idade1 * 365;

alert(`Você tem ${dias} dias e ${meses} meses`);

// 40. Receba um valor em reais e a cotação do dólar digitados pelo usuário. Em seguida, converta o valor
// para dólares e exiba o resultado.

let valorReal = Number(prompt("Digite o valor emm reais:"));
let cotacaoDolar = Number(prompt("Digite a cotação do real em dólar:"));
let valorDolar = valorReal * cotacaoDolar;

alert(valorDolar);

// 41. Solicite ao usuário para digitar um número decimal e arredonde-o para o inteiro mais próximo.

let numeroDecimal = prompt("Digite um número decimal:");
let posicaoPontoDecimal = Number(numeroDecimal?.indexOf("."));
let valorDecimal = posicaoPontoDecimal + 1;


if (posicaoPontoDecimal === null) {
    alert("Valor não decimal");
} if (valorDecimal >= 5) {
    let arredondaCima = Math.ceil(Number(numeroDecimal));
    alert(arredondaCima);
} else {
    let arredondaBaixo = Math.floor(Number(numeroDecimal));
    alert(arredondaBaixo);
}

// 42. Receba três números inteiros digitados pelo usuário e exiba o resultado da operação (n1 + n2) *
// n3.

let number1 = Number(prompt("Digite 3 números:"));
let number2 = Number(prompt("Seguno:"));
let number3 = Number(prompt("Terceiro:"));

alert((number1 + number2) * number3);

// 43. Peça ao usuário que digite uma temperatura em graus Celsius e a converta para Fahrenheit usando
// a fórmula: Fahrenheit = (Celsius * 9/5) + 32.

let temperaturaCelcius = Number(prompt("Digite uma temperatura em grau Celsius:"));
let temperaturaFahreneit = ((temperaturaCelcius) * 9/5) + 32;

alert(temperaturaFahreneit);