// Escreva um programa que leia um número inteiro e verifique se ele é positivo, negativo ou igual a
// zero.

let numero = 10

if(numero >0) {
    console.log("O número é positivo");
} else if(numero = 0) {
    console.log("O número é igual a zero");
} else {
    console.log("O número é menor que zero");
}

// 2. Crie um programa que receba a idade de uma pessoa e exiba se ela é maior de idade ou menor de
// idade.

let idade = 10;

if(idade >= 18) {
    console.log("Ele(a) é maior de idade");
} else {
    console.log("Ele(a) é menor de idade");
}

// 3. Desenvolva um programa que leia dois números inteiros e mostre qual deles é o maior, ou se são
// iguais.

let numero1 = 10,
    numero2 = 5;

if(numero1 > numero2) {
    console.log("O número1 é maior do que o número2")
} else if(numero1 < numero2) {
    console.log("O número1 é menor do que o número2")
} else {
    console.log("O número1 e o número2 são iguais")
}

// 4. Faça um programa que verifique se um número é par ou ímpar.

let numeroPar = 10;

if(numeroPar % 2 === 0) {
    console.log("O número é par");
} else {
    console.log("O número é ímpar");
}

// 5. Elabore um programa que leia três notas de um aluno e calcule a média. Em seguida, exiba se o
// aluno está aprovado (média maior ou igual a 7) ou reprovado.

let nota1 = 10,
    nota2 = 5,
    nota3 = 8;

let media = (nota1 + nota2 + nota3) / 3;

if(media >= 7) {
    console.log("O aluno está aprovado");
} else {
    console.log("O aluno está reprovado");
}

// 6. Crie um programa que receba o nome de duas pessoas e exiba qual delas possui o maior número
// de caracteres em seu nome.

let nome1 = "Marcela",
    nome2 = "Tiago";

if(nome1.length > nome2.length) {
    console.log("O primeiro nome é maior do que o segundo número");
} else if(nome1.length < nome2.length) {
    console.log("O segundo nome é maior do que o primeiro");
} else {
    console.log("Ambos os nomes possuem tamanhos iguais");
}

// 7. Desenvolva um programa que leia um caractere e verifique se ele é uma vogal ou uma consoante.

let caractere = "n";

if(caractere = "a" || "e" || "i" || "o" || "u") {
    console.log("O caractere é uma vogal")
} else {
    console.log("O caractere é uma conscoante");
}

// 8. Faça um programa que receba três números e os imprima em ordem crescente.

let listaDeNumeros = [1, 4, 2];
let listaOrdenadaDeNumeros = listaDeNumeros.sort();

console.log(listaOrdenadaDeNumeros);

// 9. Elabore um programa que calcule o IMC (Índice de Massa Corporal) de uma pessoa, dado o peso e
// a altura. Em seguida, exiba se a pessoa está abaixo do peso, com peso normal, com sobrepeso,
// obesa ou muito obesa.

let peso = 60,
    altura = 180,
    imc = peso / (altura^2);

console.log(imc);

// 10. Escreva um programa que receba um número de mês (1 a 12) e exiba o nome do mês
// correspondente.

let numeroMes = prompt("Digite o número de um mês:");
let nomeMes = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

let mes = nomeMes[Number(numeroMes) - 1];

console.log(`O mês é ${mes}`);

// 11. Desenvolva um programa que leia o salário de um funcionário e calcule o valor do seu aumento.
// Para salários superiores a R$ 1.500,00, o aumento deve ser de 10%. Caso contrário, o aumento é de
// 15%.

let salario = Number(prompt("Digite seu salário:"));

if(salario > 1500) {
    alert(salario * 1.1);
} else {
    alert(salario * 1.5);
}

// 12. Receba um número inteiro do usuário e verifique se ele é divisível por 3 e por 5 ao mesmo tempo,
// exibindo uma mensagem apropriada.

let numeroInteiro = Number(prompt("Digite um número inteiro:"));

if(numeroInteiro % 3 === 0 && numeroInteiro % 5 === 0) {
    alert("O número é divisível por 3 e 5");
}

// 13. Peça ao usuário que insira o dia da semana (por extenso) e, em seguida, exiba uma mensagem
// informando se é um dia útil ou um fim de semana.

let diaSemana = prompt("Digite o dia da semana por extenso:");
let diaSemanaLowerCase = diaSemana?.toLocaleLowerCase();
if(diaSemanaLowerCase === "sábado" || diaSemanaLowerCase === "domingo") {
    alert("Não é dia útil");
} else {
    alert("É dia útil");
}

// 14. Elabore um programa que leia um número inteiro de 1 a 5 e exiba a mensagem "Muito bom",
// "Bom", "Regular", "Insuficiente" ou "Muito insuficiente", de acordo com o valor lido, utilizando
// switch/case.

let numeroInteiro1a5 = Number(prompt("Insira um número inteiro de 1 a 5:"));

switch (numeroInteiro1a5) {
    case 5:
        alert("Muito bom");
        break;
    case 4:
        alert("Bom");
        break;
    case 3:
        alert("Regular");
        break;
    case 2:
        alert("Insuficiente");
        break;
    case 1:
        alert("Muito insuficiente");
        break;
    default:
        alert("Digite um número inteiro de 1 a 5.")
        break;
}

// 15. Peça ao usuário que digite um número entre 1 e 7 e exiba o dia da semana correspondente (1 -
// Domingo, 2 - Segunda-feira, etc.).

let numeroSemana = Number(prompt("Digite um número de 1 a 7"));

switch (numeroSemana) {
    case 1:
        alert("1 - Dommingo");
        break;
    case 2:
        alert("2 - Segunda-feira");
        break;
    case 3:
        alert("3 - Terça-feira");
        break;
    case 4:
        alert("4 - Quarta-feira");
        break;
    case 5:
        alert("5 - Quinta-feira");
        break;
    case 6:
        alert("6 - Sexta-feira");
        break;
    case 7:
        alert("7 - Sábado");
        break;
    default:
        alert("Digite um número entre 1 e 7");
        break;
}

// 16. Receba um número decimal do usuário e arredonde-o para o inteiro mais próximo usando a
// estrutura de controle try/catch para tratar exceções.


// 17. Peça ao usuário que insira a sua idade e verifique se ele é um bebê (0 a 1 ano), criança (1 a 12
// anos), adolescente (13 a 18 anos) ou adulto (mais de 18 anos).

let idadeUsuario = Number(prompt("Digite sua idade:"));

if(idadeUsuario >= 0 && idadeUsuario <= 1) {
    alert("Você é um bebê");
} else if(idadeUsuario >= 1 && idadeUsuario <= 12) {
    alert("Você é uma criança");
} else if(idadeUsuario >= 13 && idadeUsuario <= 18) {
    alert("Você é um adolescente");
} else if(idadeUsuario > 18) {
    alert("Você é um adulto");
}

// 18. Peça ao usuário que insira o seu estado civil e, usando a estrutura switch/case, exiba uma
// mensagem informando se é solteiro, casado, divorciado ou viúvo.

let estadoCivil = prompt("Digite seu estado civil:")?.toLocaleLowerCase();

switch (estadoCivil) {
    case "solteiro":
        alert("Você é solteiro");
        break;
    case "casado":
        alert("Você é casado");
        break;
    case "divorciado":
        alert("Você é divorciado");
        break;
    case "viúvo":
        alert("Você é viúvo")
        break;
    default:
        alert("Digite novamente")
        break;
}

// 19. Solicite ao usuário dois números inteiros e, usando a estrutura switch/case, exiba o resultado da
// operação escolhida pelo usuário (1 - soma, 2 - subtração, 3 - multiplicação, 4 - divisão).

let numeroInteiro1 = Number(prompt("Digite o primeiro número:"));
let numeroInteiro2 = Number(prompt("Digite o segundo número:"));
let tipoOpercao = Number(prompt("1 - soma, 2 - subtração, 3 - multiplicação, 4 - divisão"));

switch (tipoOpercao) {
    case 1:
        alert(numeroInteiro1 + numeroInteiro2);
        break;
    case 2:
        alert(numeroInteiro1 - numeroInteiro2);
        break;
    case 3:
        alert(numeroInteiro1 * numeroInteiro2);
        break;
    case 4:
        alert(numeroInteiro1 / numeroInteiro2);
    default:
        alert("Escolha uma operação entre 1 e 4.")
        break;
}

// 20. Desenvolva um programa que leia o nome e a idade de uma pessoa. Utilize o bloco try/catch para
// garantir que a idade digitada seja um valor inteiro válido.



// 21. Crie um programa que leia um valor em metros e o converta para centímetros, milímetros e
// quilômetros. Utilize o bloco try/catch para tratar possíveis exceções durante os cálculos.

