// 1. Escreva para que serve o for.
// Serve para executar um ou mais comandos em vários elementos de uma lista.

// 2. Como o comando for define o início de uma repetição?
// Estabelecendo um indicador como valor inicial da iteração.

// 3. Como o comando for determina o fim da execução?
// Estabelecendo uma condição que, quando se tornar falsa, pára a execução for.

// 4. Como ocorre a alteração do valor em cada repetição dentro da estrutura de repetição for?
// Através de comandos estabelecidos para serem usados em cada repetição.

// 5. Implemente o código do slide de número 18.
for (let i = 0; i < 10; i++) {
  console.log("Testando uma frase!");
}

// 6. Implemente o código do slide de número 26.
for (let i = 0; i < 10; i++) {
  console.log(i);
}

// 7. Implemente o código do slide de número 36.
for (let i = 0; i < 10; i++) {
  if (i === 5) {
    break;
  }
  console.log(i);
}

// 8. Implemente o código do slide de número 38.
for (let i = 0; i < 10; i++) {
  if (i === 5) {
    continue;
  }
  console.log(i);
}

// 9. Implemente o código do slide de número 44.
const nomes = ["João", "Paulo", "Pedro", "Gustavo", "Maria"];

for (let n of nomes) {
  console.log(n);
}

// 10. Faça um programa que exiba os números de 1 a 10 em ordem crescente.
for (let i = 0; i <= 10; i++) {
  console.log(i);
}

// 11. Crie um programa que exiba os números de 10 a 1 em ordem decrescente.
for (let i = 10; i >= 1; i--) {
  console.log(i);
}

// 12. Elabore um programa que calcule a soma dos números de 1 a 100.
for (let i = 1; i <= 100; i++) {
  console.log(i++);
}

// 13. Desenvolva um programa que exiba todos os números pares de 1 a 50.
for (let i = 1; i <= 50; i++) {
  if (i % 2 === 0) {
    console.log(i);
  }
}

// 14. Faça um programa que calcule o produto dos números de 1 a 5.
for (let i = 1; i <= 5; i++) {
  let multiplo = i * ++i;
  console.log(multiplo);
}

// 15. Crie um programa que exiba a tabuada do 7.
for (let i = 1; i <= 10; i++) {
  let multiploDe7 = i * ++i;
  console.log(multiploDe7);
}

// 16. Elabore um programa que calcule a média de 5 notas digitadas pelo usuário.
let listaNotas: number = 0;
let mediaNotas = listaNotas / 5;
for (let i = 0; i < 5; i++) {
  listaNotas += Number(prompt("Digite 1 nota:"))
}
console.log(mediaNotas);

// 17. Desenvolva um programa que exiba todos os múltiplos de 3 no intervalo de 1 a 50.
for (let i = 1; i <= 50; i++) {
  if(i % 3 === 0) {
    console.log(i);
  }
}

// 18. Crie um programa que leia 10 números do usuário e exiba o maior e o menor valor digitado.
let maiorNumero: number[] = [];
let numero: number;
for (let i = 1; i < 11; i++) {
  numero = Number(prompt("Digite um número:"));
  maiorNumero.push(numero);
}
maiorNumero.sort((a, b) => a - b);
console.log(`Menor número: ${maiorNumero[0]}, e maior número: ${maiorNumero[10]}`);

// 19. Faça um programa que exiba os números ímpares de 1 a 100.
let numerosImpares: number[] = [];
for (let i = 1; i <= 100; i++) {
  if(i % 2 !== 0) {
    numerosImpares.push(i)
  }
  console.log(numerosImpares);
}

// 20. Crie um programa que leia 5 notas de alunos e exiba quantos deles foram aprovados (nota maior
// ou igual a 7).
let notaAlunos: number[] = [];
let nota: number;

for (let i = 0; i <= 5; i++) {
  nota = Number(prompt("Digite uma nota:"));
  notaAlunos.push(nota);
}

let alunosAprovados = notaAlunos.length;
console.log(alunosAprovados);

// 21. Faça um programa que exiba a soma dos dígitos de um número inteiro fornecido pelo usuário.
let numeroInteiro = prompt("Digite um número inteiro:");
let digitosNumero = numeroInteiro?.split('');

if(digitosNumero != undefined) {
  let soma: number = 0;
  for (let i = 0; i < digitosNumero.length; i++) {
    soma += Number(digitosNumero[i]);
  }
  console.log(soma);
}

// 22. Elabore um programa que leia um número inteiro e exiba todos os seus divisores.
let dividendo = Number(prompt("Digite um número inteiro:"));
let divisores: number[] = [];

for (let divisor = 1; divisor === dividendo; divisor++) {
  if(dividendo % divisor === 0) {
    divisores.push(divisor);
  }  
}
console.log(divisores);

// 23. Desenvolva um programa que calcule a média de altura de 5 pessoas.
let alturas: number[] = [];
let somaAlturas: number = 0;
let mediaAlturas: number = 0;

for(let i = 0; i <= 5; i++) {
  alturas.push(Number(prompt("Digite 5 valores de altura:")))
  somaAlturas += alturas[i];
}
mediaAlturas = somaAlturas / alturas.length;

console.log(mediaAlturas);

// 24. Faça um programa que exiba os números de 1 a 100, substituindo os múltiplos de 3 pela palavra
// "Fizz" e os múltiplos de 5 pela palavra "Buzz". Para os números que são múltiplos de ambos,
// utilize a palavra "FizzBuzz".
let listaNumeros: string[] = [];

for (let i = 1; i <= 100; i++) {
  if(i / 3 && i / 5) {
    listaNumeros.push("FizzBuzz");
  } else if( i / 3) {
    listaNumeros.push("Fizz")
  } else if(i / 5) {
    listaNumeros.push("Buzz")
  } else {
    listaNumeros.push(i.toString());
  }
}

// 25. Elabore um programa que leia um número inteiro e exiba a soma dos dígitos pares desse número.
let numeroInteiro1 = prompt("Digite um número inteiro:");
let listaDigitos = numeroInteiro1?.split('');
let somaDigitos: number = 0;

if(listaDigitos != undefined) {
  for (let i = 0; i < listaDigitos.length; i++) {
  if(Number(listaDigitos[i]) % 2 === 0) {
      somaDigitos += Number(listaDigitos[i])
    }
}
}
console.log(somaDigitos);

// 26. Faça um programa que leia um número inteiro e exiba o número invertido. Por exemplo, se o
// número lido for 123, o programa deve exibir 321.
let numeroInteiro2 = prompt("Digite um número inteiro:");
let listaDigitosNumeroInteiro = numeroInteiro2?.split('');

if(listaDigitosNumeroInteiro !== undefined) {
  listaDigitosNumeroInteiro?.sort((a, b) => b - a);
}
